import logo from './logo.svg';
import './App.css';
import { MemberList } from "./MemberList";

function App() {

    return (
    <div className="App">
      <header className="App-header">
        <div>
          <MemberList></MemberList>
        </div>
      </header>
    </div>
  );
}
export default App;
