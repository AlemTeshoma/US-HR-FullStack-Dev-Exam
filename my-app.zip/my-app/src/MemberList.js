import React, {Component, useEffect, useState } from 'react';
import { Member } from "./Member";
import ReactPaginate from 'react-paginate'
import $ from "jquery";
import "../node_modules/bootstrap/dist/css/bootstrap.css"
import  {Container, Row, Col, Box, Button} from "reactstrap";
import "react-dropdown/style.css";

export class MemberList extends Component{
    constructor(props) {
        super(props);
        this.state = {
            memberData: [],
            offset: 0,
            pageCount: 0,
            skipCount: 0,
            sortBy: '',
            sortDirection: 'asc'
        };
    }
    loadMembersfromServer() {
        //Paginated endpoint url with filters
        let odataurl = `https://clerkapi.azure-api.net/Members/v1/?key=61888da502844defa16dd86096aea78f&$filter=active eq 'yes'&$skip=` + this.state.offset + '&$top=10';
        
        //Decorating odataurl with sort fields and sort type (asc / desc)
        if(this.state.sortBy.trim() !== '') {
            switch(this.state.sortBy.trim()) {
                case 'name': 
                    if(this.state.sortDirection === 'asc')
                    odataurl = odataurl + '&$orderby=officialName asc';
                    else
                    odataurl = odataurl + '&$orderby=officialName desc';
                    break;
                case 'state': 
                    if(this.state.sortDirection === 'asc')
                    odataurl = odataurl + '&$orderby=congresses/stateCode asc';
                    else
                    odataurl = odataurl + '&$orderby=congresses/stateCode desc';
                    break;
                case 'party': 
                    if(this.state.sortDirection === 'asc')
                    odataurl = odataurl + '&$orderby=congresses/partyAffiliations/name asc';
                    else
                    odataurl = odataurl + '&$orderby=congresses/partyAffiliations/name desc';
                    break;
            }
        }

        //Using jQuery ajax call to get data from the api
        $.ajax({
            url: odataurl,
            dataType: 'json',
            type: 'GET',
            success: (data) => {            //success handler
                this.setState({
                    memberData: data.results,
                    pageCount: data.pagination.number_pages
                });
            },
            error: (xhr, status, err) => {  //error handler
                console.log('error');
            }
        })
    }

    componentDidMount() {
        //Initial data loading on component mount
        this.loadMembersfromServer();
    }

    //sort handler
    handleSorting= (data) => {
        this.setState({
            sortBy: data.target.value
        }, () => {
            this.loadMembersfromServer();
        });                
    }

    //sort direction handler
    handleSortDirection= (data) => {
        this.setState({
            sortDirection: data.target.value
        }, () => {
            this.loadMembersfromServer();
        });                
    }

    //handler to get paginated data and load on UI
    handlePageClick = (data) => {
        let selected = data.selected;
        let offset = Math.ceil(selected * 10);

        this.setState({offset: offset}, () => {
            this.loadMembersfromServer();
        });
    }
    
    //react render function
    render() {
    return (
            <div>
                Sorting: 
                    <select
                        value={this.state.sortBy}
                        onChange={this.handleSorting}>
                        <option value='0'>Select Sort by</option>
                        <option value='name'>Name</option>
                        <option value='party'>Party</option>
                        <option value='state'>State</option>
                    </select> 
                    Sort Order:
                        <select
                            value={this.state.sortDirection}
                            onChange={this.handleSortDirection}>
                            <option value='asc'>Ascending</option>
                            <option value='desc'>Descending</option>
                        </select>
            <br></br>
            <br></br>
            <h3>Members</h3>
                <Container>
                <Row>
                    <Col xs="6">
                        <span>Name</span>
                    </Col>
                    <Col xs="1">
                        <span>State</span>
                    </Col>
                    <Col xs="3">
                        <span>Party</span>
                    </Col>
                    <Col xs="2">
                        <span>Active</span>
                    </Col>
                </Row>
            </Container>

            {this.state.memberData.map(m => <Member id={m._id} name={m.officialName} party={m.congresses[0].partyAffiliations[0].name} state={m.congresses[0].stateCode} active={m.active} congressNum = {m.congresses[0].congressNum} />)}
            
            <ReactPaginate previousLabel={'previous'} nextLabel={'next'}  breakLabel={'...'}
            breakClassName={'break-me'} pageCount={this.state.pageCount} 
                marginPagesDisplayed={2} pageRangeDisplayed={5} onPageChange={this.handlePageClick} containerClassName={'pagination'} 
                activeClassName={'active'}/>
            </div>
        );
    }
}
