import React, {Component} from 'react';
import {Container, Row, Col, Box} from "reactstrap";
import Modal from 'react-bootstrap/Modal'
import Button from 'react-bootstrap/Button'
import { VotesList } from './VotesList';

// Component for modal popup that displays member specific votes information
export class VotesModal extends Component{
    constructor(props) {
        super(props);
        this.state = {
            data: []
        };
    }
    
    render() {
        return (
            <div>
                <Modal show={this.props.modalOpen} onhide={this.props.handlePopup} >
                    <Modal.Header>Votes for congressnum -  {this.props.congressNum}</Modal.Header>
                    <Modal.Body>
                        <VotesList congressNum={this.props.congressNum} id={this.props.id}></VotesList>
                    </Modal.Body>
                    <Modal.Footer>
                        <Button variant='danger' onClick={this.props.handlePopup}>cancel</Button>
                    </Modal.Footer>
                </Modal>
            </div>
        );
    }
}