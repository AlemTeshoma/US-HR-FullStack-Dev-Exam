import React, {Component} from 'react';
import  {Container, Row, Col } from "reactstrap";
import {VotesModal} from './VotesModal'

export class Member extends Component {
    constructor(props) {
        super(props);
        this.state = {
            modalOpen: false
        };
    }

    //event handler to show/hide popup
    handlePopup = () => {
        this.setState((prevState) => {
            return{
               modalOpen: !prevState.modalOpen
            }
         })
    }
    render() {
        return (
                <div>
                    <Container>
                        <Row>
                            <Col xs="6">
                                <a onClick={this.handlePopup} className="nav-link"><span>{this.props.name}</span></a>
                            </Col>
                            <Col xs="1">
                                <span>{this.props.state}</span>
                            </Col>
                            <Col xs="3">
                                <span>{this.props.party}</span>
                            </Col>
                            <Col xs="2">
                                <span>{this.props.active}</span>
                            </Col>
                            
                        </Row>
                    </Container>

                    <VotesModal modalOpen={this.state.modalOpen} handlePopup={this.handlePopup} congressNum={this.props.congressNum} id={this.props.id}></VotesModal>
                </div>
            );
    }
}
