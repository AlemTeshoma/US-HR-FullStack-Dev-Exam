import React, {Component} from 'react';
import  {Container, Row, Col } from "reactstrap";

export class Votes extends Component {
    constructor(props) {
        super(props);
        this.state = {
            votes: []
        };
    }
    render() {
        return (
            <div>
                <Container>
                    <Row>
                        <Col xs="6">
                            <span>{this.props.name}</span>
                        </Col>
                        <Col xs="4">
                            <span>{this.props.voteQuestion}</span>
                        </Col>
                        <Col xs="2">
                            <span>{this.props.result}</span>
                        </Col>
                    </Row>
                </Container>
            </div>
        );
    }
}
