import React, {Component, useEffect, useState } from 'react';
import { Votes } from "./Votes";
import ReactPaginate from 'react-paginate'
import $ from "jquery";
import "../node_modules/bootstrap/dist/css/bootstrap.css"
import  {Container, Row, Col, Box, Button} from "reactstrap";
import "react-dropdown/style.css";

export class VotesList extends Component{
    constructor(props) {
        super(props);
        this.state = {
            votesData: [],
            offset: 0,
            pageCount: 0,
            skipCount: 0
        };
    }
    loadVotesfromServer(jQ) {
        let odataurl = `https://clerkapi.azure-api.net/Votes/v1/?key=61888da502844defa16dd86096aea78f&$filter=superEvent/superEvent/congressNum eq '${this.props.congressNum}' and members/any(member: member/usCongressBio eq '${this.props.id}' and member/vote eq 'Yea')&$skip=` + this.state.offset + '&$top=10';
        
        jQ.ajax({
            url: odataurl,
            dataType: 'json',
            type: 'GET',
            success: (data) => {            //success handler
                this.setState({
                    votesData: data.results,
                    pageCount: data.pagination.number_pages
                });
            },
            error: (xhr, status, err) => {  //error handler
                console.log('error');
            }
        })
    }

    componentDidMount() {
        //load data once modal component is mounted
        this.loadVotesfromServer($);
    }

    //pagination handler
    handlePageClick = (data) => {
        let selected = data.selected;
        let offset = Math.ceil(selected * 10);

        this.setState({offset: offset}, () => {
            //load paginated data based on offset
            this.loadVotesfromServer($);
        });
    }
    
    render() {
    return (
        <div>
            <Container>
            <Row>
                <Col xs="6">
                    <span>Name</span>
                </Col>
                <Col xs="4">
                    <span>voteQuestion</span>
                </Col>
                <Col xs="2">
                    <span>Results</span>
                </Col>
            </Row>
        </Container>
        {this.state.votesData.map(m => <Votes name={m.name} voteQuestion={m.voteQuestion} result={m.result}/>)}
        <ReactPaginate previousLabel={'previous'} nextLabel={'next'}  breakLabel={'...'}
          breakClassName={'break-me'} pageCount={this.state.pageCount} 
            marginPagesDisplayed={2} pageRangeDisplayed={5} onPageChange={this.handlePageClick} containerClassName={'pagination'} 
            activeClassName={'active'}/>
        </div>
        );
    }
}
